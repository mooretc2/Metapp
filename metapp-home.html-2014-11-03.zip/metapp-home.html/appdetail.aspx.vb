﻿
Partial Class appdetail
    Inherits System.Web.UI.Page

End Class
